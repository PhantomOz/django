from django.shortcuts import render

# Create your views here.
def helloworld(request):
    return render(request,"helloworld/helloworld.html")
def student(request):
    return render(request,"student/student.html")