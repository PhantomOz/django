from django.apps import AppConfig


class AsofappConfig(AppConfig):
    name = 'asofapp'
